# Azure Cost Analysis

###  Service names by Group

virtual machines,azure app service,logic apps,virtual machines licenses,functions,cloud services,azure 

azure cosmos db,sql database,redis cache,azure database for mysql,azure database for postgresql

event hubs,service bus,event grid,stream analytics

azure monitor, application insights,log analytics,insight and analytics

sentinel,security center,advanced data security,advanced threat protection

bandwidth,virtual network,traffic manager,application gateway,network watcher,expressroute,azure firewall,vpn gateway

azure data factory,azure data factory v2,data lake store,azure databricks,

storage,backup,azure netapp files,storsimple

cognitive search,app configuration,cognitive services,api management

automation,azure bastion,azure devops,visual studio online

container registry,container instances

key vault,unassigned