# Change Log

Change history of the project. All the feature updates, bug fixes, breaking changes will be documented here.

## [ 0.1.0 ]

- First stable version
- Sample dashboard included
- **Breaking Change** : Plugin ID, Name changed. Refer [#13](https://github.com/yesoreyeram/grafana-azure-datasource/issues/13)

## [ 0.0.1 ]

- First working version
